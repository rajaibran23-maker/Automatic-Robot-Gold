package com.example.gridbot

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.graphics.Typeface
import android.view.ViewGroup
import android.widget.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val executor = Executors.newSingleThreadExecutor()
    private lateinit var backend: EditText
    private lateinit var apiKey: EditText
    private lateinit var login: EditText
    private lateinit var password: EditText
    private lateinit var server: EditText
    private lateinit var symbol: EditText
    private lateinit var status: TextView
    private lateinit var autoButton: Button
    private var auto = false
    private var selected = "builtin"
    private val PICK_STRATEGY = 701

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(28,24,28,24) }
        fun field(hint: String, secret: Boolean = false): EditText = EditText(this).apply {
            this.hint = hint; if (secret) inputType = 129
            layout.addView(this, ViewGroup.LayoutParams(-1, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        layout.addView(TextView(this).apply { text="GRIDBOT MT5"; textSize=26f; typeface=Typeface.DEFAULT_BOLD })
        layout.addView(TextView(this).apply { text="Connect to your Windows MT5 backend. DEMO only for testing."; textSize=14f })
        backend=field("Backend URL (https://your-private-host)")
        apiKey=field("Backend API Key",true); login=field("MT5 account number")
        password=field("MT5 password",true); server=field("MT5 server name")
        symbol=field("Symbol (e.g. XAUUSDm)").apply { setText("XAUUSDm") }
        val connect=Button(this).apply { text="CONNECT MT5" }; layout.addView(connect)
        val import=Button(this).apply { text="IMPORT STRATEGY JSON FILE" }; layout.addView(import)
        val built=Button(this).apply { text="USE BUILT-IN STRATEGY" }; layout.addView(built)
        val imported=Button(this).apply { text="USE IMPORTED STRATEGY" }; layout.addView(imported)
        autoButton=Button(this).apply { text="RUN SELECTED STRATEGY: OFF"; isEnabled=false }; layout.addView(autoButton)
        val disconnect=Button(this).apply { text="DISCONNECT" }; layout.addView(disconnect)
        val refresh=Button(this).apply { text="REFRESH STATUS" }; layout.addView(refresh)
        status=TextView(this).apply { text="Status: Not connected\nLots: 0.01, 0.02, 0.04, 0.06"; textSize=16f }; layout.addView(status)
        layout.addView(TextView(this).apply { text="Imported file support: JSON strategy profiles only (not .mq5/.ex5 or executable scripts). Imported profile takes over; built-in strategy is not run at the same time. Loss can exceed -$50."; textSize=13f })
        setContentView(ScrollView(this).apply { addView(layout) })
        connect.setOnClickListener {
            val body=JSONObject().put("login",login.text.toString().toLongOrNull()?:0).put("password",password.text.toString()).put("server",server.text.toString()).put("symbol",symbol.text.toString())
            request("POST","/connect",body) { r -> status.text="Connected: ${r.optString("login")}\nMode: ${r.optString("account_mode")}\nStrategy: $selected"; autoButton.isEnabled=true }
        }
        import.setOnClickListener { if(auto) { toast("Turn strategy OFF before importing"); return@setOnClickListener }; val i=Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type="application/json" }; startActivityForResult(i,PICK_STRATEGY) }
        built.setOnClickListener { chooseStrategy("builtin") }
        imported.setOnClickListener { chooseStrategy("imported") }
        autoButton.setOnClickListener {
            val next=!auto
            if(next) android.app.AlertDialog.Builder(this).setTitle("Run strategy?").setMessage("Use DEMO only. Automated trading sends MT5 orders; loss may exceed the configured limit.").setNegativeButton("CANCEL",null).setPositiveButton("I UNDERSTAND") { _,_ -> setAuto(true) }.show()
            else setAuto(false)
        }
        disconnect.setOnClickListener { request("POST","/disconnect",JSONObject()) { auto=false; autoButton.text="RUN SELECTED STRATEGY: OFF"; autoButton.isEnabled=false; status.text="Disconnected" } }
        refresh.setOnClickListener { request("GET","/status",null) { r -> auto=r.optBoolean("auto_trading"); selected=r.optString("selected_strategy",selected); autoButton.text=if(auto) "RUN SELECTED STRATEGY: ON" else "RUN SELECTED STRATEGY: OFF"; status.text="Connected: ${r.optBoolean("connected")}\nMode: ${r.optString("account_mode")}\nSelected: $selected\nAuto: $auto\nPositions: ${r.optInt("positions")}\nBasket P/L: ${r.optDouble("basket_profit")}\nError: ${r.optString("last_error")}" } }
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?) { super.onActivityResult(requestCode,resultCode,data); if(requestCode==PICK_STRATEGY && resultCode==RESULT_OK) { val uri=data?.data ?: return; uploadStrategy(uri) } }
    private fun uploadStrategy(uri:Uri) {
        val bytes=contentResolver.openInputStream(uri)?.use { it.readBytes() } ?: run { toast("Cannot read file"); return }
        val base=backend.text.toString().trim().trimEnd('/'); val key=apiKey.text.toString(); val name=uri.lastPathSegment?.substringAfterLast('/') ?: "strategy.json"
        if(!base.startsWith("https://")) { toast("Use HTTPS backend URL"); return }
        executor.execute { try { val c=(URL(base+"/strategy/import").openConnection() as HttpURLConnection).apply { requestMethod="POST"; connectTimeout=10000; readTimeout=15000; setRequestProperty("X-API-Key",key); setRequestProperty("X-Filename",if(name.endsWith(".json")) name else "strategy.json"); doOutput=true; setRequestProperty("Content-Type","application/json"); outputStream.use { it.write(bytes) } }; val stream=if(c.responseCode in 200..299)c.inputStream else c.errorStream; val txt=stream.bufferedReader().use{it.readText()}; c.disconnect(); val r=JSONObject(txt); runOnUiThread { if(r.has("detail")) toast(r.optString("detail")) else { selected="imported"; status.text="Imported profile selected\nLots: ${r.optJSONArray("lots")}"; toast("Imported strategy JSON loaded") } } } catch(e:Exception) { runOnUiThread { toast("Import failed: ${e.message}") } } }
    }
    private fun chooseStrategy(mode:String) { request("POST","/strategy/select",JSONObject().put("mode",mode)) { selected=mode; status.text="Selected strategy: $mode\nRun button will control only this strategy."; toast("Selected: $mode") } }
    private fun setAuto(enabled:Boolean) { request("POST","/auto",JSONObject().put("enabled",enabled)) { auto=enabled; autoButton.text=if(auto) "RUN SELECTED STRATEGY: ON" else "RUN SELECTED STRATEGY: OFF" } }
    private fun toast(s:String) { Toast.makeText(this,s,Toast.LENGTH_LONG).show() }
    private fun request(method:String,path:String,body:JSONObject?,done:(JSONObject)->Unit) {
        val base=backend.text.toString().trim().trimEnd('/'); val key=apiKey.text.toString()
        if(!base.startsWith("https://")) { toast("Use HTTPS backend URL"); return }
        executor.execute { try { val c=(URL(base+path).openConnection() as HttpURLConnection).apply { requestMethod=method; connectTimeout=10000; readTimeout=15000; setRequestProperty("X-API-Key",key); if(body!=null){doOutput=true;setRequestProperty("Content-Type","application/json");outputStream.use{it.write(body.toString().toByteArray(Charsets.UTF_8))}} }; val stream=if(c.responseCode in 200..299)c.inputStream else c.errorStream; val txt=stream.bufferedReader().use{it.readText()}; c.disconnect(); val r=JSONObject(txt); runOnUiThread { if(r.has("detail")) { status.text="ERROR: ${r.optString("detail")}"; toast(r.optString("detail")) } else done(r) } } catch(e:Exception) { runOnUiThread { status.text="Connection error: ${e.message}"; toast("Connection error: ${e.message}") } } }
    }
}
